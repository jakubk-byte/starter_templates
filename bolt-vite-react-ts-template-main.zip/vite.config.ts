import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    host: '0.0.0.0',
    port: 5173,
  },
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
  build: {
    cssCodeSplit: false,
    assetsInlineLimit: 100000000, 
    rollupOptions: {
      output: {
        manualChunks: undefined,
        entryFileNames: `assets/bundle.js`,
        chunkFileNames: `assets/bundle.js`,
        assetFileNames: `assets/bundle.[ext]`,
      },
    },
  },
})
